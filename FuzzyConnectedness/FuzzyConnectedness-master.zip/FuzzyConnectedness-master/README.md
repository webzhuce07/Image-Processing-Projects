# FuzzyConnectedness   
必须结合openCV使用   
本仓库有6个相关工程：   
1.FC_Dijkstra为Dijkstra版本的FC计算方法，由于和FC定义不完全一致，故做对比之用。   
2.FuzzyConnectednessNew-Udopa为原始版本的FC计算方法，单种子点，根据纯灰度值计算。   
3.FuzzyConnectednessNew-wz为种子点区域扩张的FC计算方法，单种子点，根据灰度值、梯度、标准差计算。   
4.FuzzyConnectednessNew-fin为种子点区域扩张多种子点输入的计算方法，根据灰度值、梯度、标准差计算。   
另外两个为中期试验工程，功能不完整。
